create trigger players_logs_AFTER_INSERT
  after INSERT
  on players_logs
  for each row
  BEGIN
	IF (NEW.tipo_conteudo = 'player') AND (NEW.tipo_log = 'player') THEN    
		UPDATE players SET app_last_init = NEW.horario WHERE id = NEW.player_id;
	END IF;
END;

